/*
 *
 * RangingNegotiationPage reducer
 *
 */

import {fromJS} from 'immutable';
import {
    DEFAULT_ACTION,
    GENERATE_URL_PARAMS,
    FETCH_DATA_SUCCESS,
    URL_PARAM,
    WEEK_FETCH,
    GENERATE_SIDE_FILTER_SUCCESS,
    GENERATE_URL_PARAMS_STRING,
    GRAPH_FETCH_SUCCESS,
    FILTER_FETCH,
    FILTER_FETCH_SUCCESS, GENERATE_TABLE_SUCCESS
} from './constants';

const initialState = fromJS({
    chartData: [
      {
        x: 200,
        y: 100,
        ros: 20
    },
      {
        x: 160,
        y: 200,
        ros: 10
    },
      {
        x: 240,
        y: 250,
        ros: 20
    },
      {
        x: 320,
        y: 50,
        ros: 10
    },
    {
        x: 400,
        y: 70,
        ros: 10
    },
    {
        x: 430,
        y: 70,
        ros: 10
    }],
    urlParamsString:''
});

function rangingNegotiationPageReducer(state = initialState, action) {
    switch (action.type) {

        //For table
            case GENERATE_TABLE_SUCCESS:
            console.log(GENERATE_TABLE_SUCCESS, 'reducer', action);
            return state.set('data', action.data);
//For graph
      case GRAPH_FETCH_SUCCESS:
            console.log(GRAPH_FETCH_SUCCESS, 'reducer', action);
            return state.set('chartData', action.data);

            //This will keep the changed state of the url when anything is clicked
    //For performance filters
      case FILTER_FETCH:
            console.log(FILTER_FETCH, 'reducer', action);
            return state.set('filterType', action.data);

      case FILTER_FETCH_SUCCESS:
            console.log(FILTER_FETCH_SUCCESS, 'reducer', action);
            return state.set('filteredData', action.data);

//For side filters
        case URL_PARAM:
            console.log(URL_PARAM, 'reducer', action);
            return state.set('urldata', action.data);
        case WEEK_FETCH:
            console.log(WEEK_FETCH, 'reducer', action);
            return state.set('weekNumber', action.data);

        case GENERATE_SIDE_FILTER_SUCCESS:
            // console.log(action);
            return state.set('sideFilter', action.data);
        case GENERATE_URL_PARAMS:
            return state.set('urlParams', action.data);
        case GENERATE_URL_PARAMS_STRING:
            return state.set('urlParamsString', action.data);
        default:
            return state;
    }
}

export default rangingNegotiationPageReducer;
