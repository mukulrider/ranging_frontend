// import { fromJS } from 'immutable';
// import { makeSelectRangingNegotiationPageDomain } from '../selectors';

// const selector = makeSelectRangingNegotiationPageDomain();

describe('makeSelectRangingNegotiationPageDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
