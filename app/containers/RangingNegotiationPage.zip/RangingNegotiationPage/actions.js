/*
 *
 * RangingNegotiationPage actions
 *
 */

import {
  DEFAULT_ACTION,FETCH_DATA, FETCH_DATA_SUCCESS , URL_PARAM , WEEK_FETCH, GENERATE_FILE,
  GENERATE_TABLE, GENERATE_TABLE_SUCCESS,
  GENERATE_SIDE_FILTER, GENERATE_SIDE_FILTER_SUCCESS, GENERATE_URL_PARAMS, GENERATE_URL_PARAMS_STRING, GRAPH_FETCH,GRAPH_FETCH_SUCCESS,
    FILTER_FETCH,FILTER_FETCH_SUCCESS
} from './constants';

export function defaultAction() {
  return {
    type: DEFAULT_ACTION,
  };
}


export function WeekClick(data) {
    console.log('Nego data fetch action');
    return {
        type: WEEK_FETCH, data
    };
}




export function fetchDataSuccess(data) {
    console.log('apiFetchSuccess action', data);
    return {
        type: FETCH_DATA_SUCCESS,
        data
    };
}

export function urlDataSuccess(data) {
    console.log('apiFetchSuccess action', data);
    return {
        type: URL_PARAM,
        data
    };
}



export function generateFile() {
  return {
    type: GENERATE_FILE
  }
}

export function generateTable() {
  return {
    type: GENERATE_TABLE
  }
}

export function generateTableSuccess(data) {
    console.log('generateTableSuccess', data);
    return {
    type: GENERATE_TABLE_SUCCESS,
    data
  }
}

export function generateSideFilter() {
  return {
    type: GENERATE_SIDE_FILTER
  }
}

export function generateSideFilterSuccess(data) {
  return {
    type: GENERATE_SIDE_FILTER_SUCCESS,
    data
  }
}

export function generateUrlParams(data) {
  // console.log(data);
  return {
    type: GENERATE_URL_PARAMS,
    data
  }
}
export function generateUrlParamsString(data) {
  // console.log(data);
  return {
    type: GENERATE_URL_PARAMS_STRING,
    data
  }
}

export function fetchGraph() {
  // console.log(data);
  return {
    type: GRAPH_FETCH
  }
}

export function fetchGraphSuccess(data) {
  // console.log(data);
  return {
    type: GRAPH_FETCH_SUCCESS,
    data
  }
}
export function fetchPerformanceFilter(data) {
  console.log("action saving state");
  console.log(data);
  return {
    type: FILTER_FETCH,
      data
  }
}

export function fetchPerformanceFilterSuccess(data) {
  // console.log(data);
  return {
    type: FILTER_FETCH_SUCCESS,
    data
  }
}

