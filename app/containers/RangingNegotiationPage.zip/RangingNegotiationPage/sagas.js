// import { take, call, put, select } from 'redux-saga/effects';

import {take, call, put, select, cancel, takeLatest} from 'redux-saga/effects';
import {LOCATION_CHANGE} from 'react-router-redux';
import request from 'utils/request';

import {
    FETCH_DATA, WEEK_FETCH, GRAPH_FETCH, FILTER_FETCH
} from './constants';
import {
    fetchDataSuccess, fetchGraphSuccess, fetchPerformanceFilterSuccess
} from 'containers/RangingNegotiationPage/actions';
// Individual exports for testing
export function* defaultSaga() {
    // See example in containers/HomePage/sagas.js
}
import {selectRangingNegotiationPageDomain} from 'containers/RangingNegotiationPage/selectors';

import {
    ajaxRequest, ajaxRequestSuccess, ajaxRequestError,
    generateTableSuccess, generateSideFilterSuccess
} from 'containers/RangingNegotiationPage/actions';
import {
    makeUrlParams, makeUrlParamsString, makeTextBoxQueryString,
    makeNewScenarioString, makeNewScenarioWeek, makeNewScenarioStoreFormat
} from 'containers/RangingNegotiationPage/selectors';
import {
    //AJAX_REQUEST, AJAX_REQUEST_SUCCESS, AJAX_REQUEST_ERROR,
    GENERATE_FILE, GENERATE_TABLE,
    GENERATE_SIDE_FILTER_SUCCESS, GENERATE_SIDE_FILTER,URL_PARAM
} from './constants';



export function* generateWeekFetch() {

    let urlParamsString = yield select(selectRangingNegotiationPageDomain());

    let urlName = yield select(selectRangingNegotiationPageDomain());

    let urlParams = urlName.get('weekNumber');


    let paramString = '';
    Object.keys(urlParams).map(obj => {
        console.log(obj, urlParams[obj]);
        paramString += `&${obj}=${urlParams[obj]}`
    })

    //paramString = paramString + '&week=' + urlParams;
    paramString = paramString.replace('&', '');

    try {
        const data = yield call(request, `http://172.20.247.24:8000/ranging/default_data_for_nego_charts?` + paramString);
        yield put(fetchDataSuccess(data));
    } catch (err) {
        // console.log(err);
    }
}


export function* doWeekFetch() {
    const watcher = yield takeLatest(WEEK_FETCH, generateWeekFetch);
    yield take(LOCATION_CHANGE);
    yield cancel(watcher);
}


/* GENERATE SIDE FILTER*/
export function* generateSideFilter() {
    try {
        // todo: update url
        const data = yield call(request, `http://172.20.246.141:8000/ranging/nego/filter_data`);
        // // console.log(data);
        yield put(generateSideFilterSuccess(data));
    } catch (err) {
        // console.log(err);
    }
}

export function* doGenerateSideFilter() {
    const watcher = yield takeLatest(GENERATE_SIDE_FILTER, generateSideFilter);
    yield take(LOCATION_CHANGE);
    yield cancel(watcher)
}

/* GENERATE TABLE */
export function* generateTable() {
//This will get the object which will contain all the data saved in the reducer. It will have chart data, urlParamsString,urlData,Table data, sidefilter
    let urlParamsString = yield select(makeUrlParamsString());
  console.log("finally getting to know urlParamsString",urlParamsString);

  //To fetch the specific urlParamsString
  urlParamsString = urlParamsString.urlParamsString;

  let urlName = yield select(selectRangingNegotiationPageDomain());

  let urlParams = urlName.get('urldata');

  let paramString = '';
  Object.keys(urlParams).map(obj => {
    console.log(obj, urlParams[obj]);
    paramString += `&${obj}=${urlParams[obj]}`
  })

  paramString = paramString.replace('&', '');

  try {

        const data = yield call(request, `http://172.20.246.141:8000/ranging/nego_bubble_table?${urlParamsString + paramString}`);
        yield put(generateTableSuccess(data));
    } catch (err) {
        // console.log(err);
    }
}

export function* doGenerateTable() {
    const watcher = yield takeLatest(GENERATE_TABLE, generateTable);
    yield take(LOCATION_CHANGE);
    yield cancel(watcher)
}
/* GENERATE GRAPH */

export function* generateGraph() {
  let urlParamsString = yield select(makeUrlParamsString());
  urlParamsString = urlParamsString.urlParamsString;

  let urlName = yield select(selectRangingNegotiationPageDomain());

  console.log("under generate graph",urlName );
  let urlParams = urlName.get('urldata');
   console.log("Getting url params from ",urlParams);

  let paramString = '';
  Object.keys(urlParams).map(obj => {
    console.log(obj, urlParams[obj]);
    paramString += `&${obj}=${urlParams[obj]}`
  })

  // //paramString = paramString + '&week=' + urlParams;
   paramString = paramString.replace('&', '');

   try {
        console.log('Checking params for graph unnder try', urlParamsString);
        const data = yield call(request, `http://172.20.246.141:8000/ranging/nego_bubble_chart?${urlParamsString + paramString}`);
        yield put(fetchGraphSuccess(data));
    } catch (err) {
        // console.log(err);
    }
}

export function* doGenerateGraph() {
    const watcher = yield takeLatest(GRAPH_FETCH, generateGraph);
    yield take(LOCATION_CHANGE);
    yield cancel(watcher)
}

export function* GeneratePFilter() {
    //urlName will contain the data for all the elements required - filters, table and charts
    let urlName = yield select(selectRangingNegotiationPageDomain());
    console.log("urlName");
    console.log(urlName);

    //This will extract the field mentioned in get
    let urlParams = urlName.get('filterType');

    console.log("urlParams");
    console.log(urlParams);

    let paramString = '';

    paramString = paramString + '&performance_quartile=' + urlParams;
    paramString = paramString.replace('&', '');
    console.log("paramString");
    console.log(paramString);
    console.log("Printing url");
    console.log('http://172.20.246.140:8000/ranging/nego_bubble_table?' + paramString);

    try {
        const data = yield call(request, `http://172.20.246.141:8000/ranging/nego_bubble_table?` + paramString);
        console.log("Filtered Data");
        console.log(data);

        yield put(fetchPerformanceFilterSuccess(data));

    } catch (err) {
        console.log(err);
    }
}

export function* doGeneratePFilter() {
    console.log("indoGenerateFilter");
    const watcher = yield takeLatest(FILTER_FETCH, GeneratePFilter);
    yield take(LOCATION_CHANGE);
    yield cancel(watcher)
}
// All sagas to be loaded
export default [
    defaultSaga,
    doWeekFetch,
    doGenerateSideFilter,
    doGenerateTable,
    doGenerateGraph,
    doGeneratePFilter
];
