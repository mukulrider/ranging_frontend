// import React from 'react';
// import { shallow } from 'enzyme';

// import SelectorNegotiation from '../index';

describe('<SelectorNegotiation />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
