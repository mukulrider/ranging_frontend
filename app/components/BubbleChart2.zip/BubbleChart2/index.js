/**
 *
 * BubbleChart2
 *
 */

import React from 'react';
import * as d3 from 'd3';
import {browserHistory} from 'react-router';


class BubbleChart2 extends React.PureComponent { // eslint-disable-line react/prefer-stateless-function
    createChart = (data2) => {

      //Chart configurations

      let margin = {top: 20, right: 20, bottom: 40, left: 30};
      let width = 700-margin.left-margin.right,
        height = 600-margin.top-margin.bottom;

      let svg = d3.select('#svgg');

      console.log("long_description");
      console.log(data2[1].long_description);

      svg.selectAll("*").remove();
        //Adjusting position of the svg area
        let chart = svg.append("g").attr("transform", "translate(" + margin.left + "," + margin.top + ")");


        let xScale = d3.scaleLinear().domain([0, d3.max(data2, function (d) {
            return d.cps;
        })+10]).range([0, width]);

        let yScale = d3.scaleLinear().domain([0, d3.max(data2, function (d) {
            return d.pps;
        })+10]).range([height, 0]);

        let rScale = d3.scaleLinear().domain([0, d3.max(data2, function (d) {
            return d.rate_of_sale;
        })]).range([2, 10]);


        let color = d3.scaleLinear().range(d3.schemeCategory20b);

        let myMouseoverFunction = function() {
        alert("Harshit");
      }


        let xAxis = d3.axisBottom(xScale)
            .tickFormat(function (d) {
                return (Math.round(d*10)/10);
            });

        let yAxis = d3.axisLeft(yScale)
            .tickFormat(function (d) {
                return (Math.round(d*10)/10);
            });

      // ---------- Appending AXIS to chart -----------------
        chart.append("g")
            .attr("transform", "translate(" + margin.left + ", " + height  + ")")
            .classed("axis", true)
            .call(xAxis);

        chart.append("g")
            .attr("transform", "translate(" + margin.left + ",0)")
            .classed("axis", true)
            .call(yAxis);



      // ------------- Adding data points-----------------
        chart.selectAll('circle')
            .data(data2)
            .enter()
            .append('circle')
            .attr("cx", function (d) {

                return (margin.left + xScale(d.cps));
            })
            .attr("cy", function (d) {

                return (yScale(d.pps));
            })
          .on('click',()=>{ alert("Woo hoo")})
            .attr("r", 0)
            .transition()
            .duration(2000)
            .attr("r", function (d) {
                return (rScale (d.rate_of_sale));
            })
            .attr("fill", "green");

      //console.log("location and pathname in bubble",this.props.location.pathname);
      // .on("click", myMouseoverFunction);
        // .on("mouseover", function (d) {
        //
        //   console.log(d);});
      // let label = d3.select(this);
      //     label.append("text")
      //       .text(function(d){return (d.long_description)})
      //       .style("left", d3.event.pageX + "px")
      //          .style("top", d3.event.pageY + "px");
      // });

      // .on("mouseout", function () {
      //   // Hide the tooltip
      //   d3.select("#tooltip")
      //     .style("opacity", 0);
      // });


      //This is for getting the axis labels
      chart.append("text")
            .attr("transform",
                "translate(" + (width/2) + " ," +(height + (margin.top*1.75)) + ")")
            .style("text-anchor", "middle")
            .text("CPS - Q");

       chart.append("text")
        .attr("transform", "rotate(-90)")
        .attr("y", 0 - margin.left)
        .attr("x",0 - (height / 2))
        .attr("dy", "1em")
        .style("text-anchor", "middle")
        .text("PPS - Q");

    };

    componentDidMount = () => {
        this.createChart(this.props.data)
    };

    componentDidUpdate = () => {
        this.createChart(this.props.data)
    };

    render() {
        return (
            <div>
                <svg id="svgg" width="800" height="600" fontFamily="sans-serif" fontSize="10"
                     textAnchor="middle"> </svg>
            </div>
        );
    }
}

BubbleChart2.propTypes = {};

export default BubbleChart2;
