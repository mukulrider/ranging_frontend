/*
 * BubbleChart2 Messages
 *
 * This contains all the text for the BubbleChart2 component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.BubbleChart2.header',
    defaultMessage: 'This is the BubbleChart2 component !',
  },
});
