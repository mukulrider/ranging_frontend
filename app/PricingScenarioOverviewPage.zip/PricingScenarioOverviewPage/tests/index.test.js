// import React from 'react';
// import { shallow } from 'enzyme';

// import { PricingScenarioOverviewPage } from '../index';

describe('<PricingScenarioOverviewPage />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
