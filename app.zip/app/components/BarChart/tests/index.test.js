// import React from 'react';
// import { shallow } from 'enzyme';

// import BarChart from '../index';

describe('<BarChart />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
