/*
 * SelectorNpdImpact Messages
 *
 * This contains all the text for the SelectorNpdImpact component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.SelectorNpdImpact.header',
    defaultMessage: 'This is the SelectorNpdImpact component !',
  },
});
