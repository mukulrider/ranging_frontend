// import React from 'react';
// import { shallow } from 'enzyme';

// import MultiSeriesLineChart from '../index';

describe('<MultiSeriesLineChart />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
