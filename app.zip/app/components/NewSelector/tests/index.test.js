// import React from 'react';
// import { shallow } from 'enzyme';

// import NewSelector from '../index';

describe('<NewSelector />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
