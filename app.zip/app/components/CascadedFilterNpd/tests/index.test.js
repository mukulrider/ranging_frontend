// import React from 'react';
// import { shallow } from 'enzyme';

// import CascadedFilterNpd from '../index';

describe('<CascadedFilterNpd />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
