// import React from 'react';
// import { shallow } from 'enzyme';

// import SelectorDelist from '../index';

describe('<SelectorDelist />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
