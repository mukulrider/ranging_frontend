/*
 * SelectorDelist Messages
 *
 * This contains all the text for the SelectorDelist component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.SelectorDelist.header',
    defaultMessage: 'This is the SelectorDelist component !',
  },
});
