/*
 * SelectorNpd Messages
 *
 * This contains all the text for the SelectorNpd component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.SelectorNpd.header',
    defaultMessage: 'This is the SelectorNpd component !',
  },
});
