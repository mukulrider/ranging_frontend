// import React from 'react';
// import { shallow } from 'enzyme';

// import SelectorNpd from '../index';

describe('<SelectorNpd />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
