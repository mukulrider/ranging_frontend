/*
 * SelectorNegotiation2 Messages
 *
 * This contains all the text for the SelectorNegotiation2 component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.SelectorNegotiation2.header',
    defaultMessage: 'This is the SelectorNegotiation2 component !',
  },
});
