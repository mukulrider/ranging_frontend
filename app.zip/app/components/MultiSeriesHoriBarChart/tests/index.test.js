// import React from 'react';
// import { shallow } from 'enzyme';

// import MultiSeriesHoriBarChart from '../index';

describe('<MultiSeriesHoriBarChart />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
