/*
 * BarChart2 Messages
 *
 * This contains all the text for the BarChart2 component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.BarChart2.header',
    defaultMessage: 'This is the BarChart2 component !',
  },
});
