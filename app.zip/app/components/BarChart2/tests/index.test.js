// import React from 'react';
// import { shallow } from 'enzyme';

// import BarChart2 from '../index';

describe('<BarChart2 />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
