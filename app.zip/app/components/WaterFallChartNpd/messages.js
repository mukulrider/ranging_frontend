/*
 * WaterFallChartNpd Messages
 *
 * This contains all the text for the WaterFallChartNpd component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.WaterFallChartNpd.header',
    defaultMessage: 'This is the WaterFallChartNpd component !',
  },
});
