// import React from 'react';
// import { shallow } from 'enzyme';

// import WaterFallChart2 from '../index';

describe('<WaterFallChart2 />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
