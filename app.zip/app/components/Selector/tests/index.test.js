// import React from 'react';
// import { shallow } from 'enzyme';

// import Selector from '../index';

describe('<Selector />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
