/*
 * MultiseriesBarChart2 Messages
 *
 * This contains all the text for the MultiseriesBarChart2 component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.MultiseriesBarChart2.header',
    defaultMessage: 'This is the MultiseriesBarChart2 component !',
  },
});
