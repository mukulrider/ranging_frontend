// import React from 'react';
// import { shallow } from 'enzyme';

// import BubbleChart2 from '../index';

describe('<BubbleChart2 />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
