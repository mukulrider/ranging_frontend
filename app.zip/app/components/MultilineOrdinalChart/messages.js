/*
 * MultilineOrdinalChart Messages
 *
 * This contains all the text for the MultilineOrdinalChart component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.components.MultilineOrdinalChart.header',
    defaultMessage: 'This is the MultilineOrdinalChart component !',
  },
});
