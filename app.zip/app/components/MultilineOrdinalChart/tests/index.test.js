// import React from 'react';
// import { shallow } from 'enzyme';

// import MultilineOrdinalChart from '../index';

describe('<MultilineOrdinalChart />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
