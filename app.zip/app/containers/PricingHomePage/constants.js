/*
 *
 * PricingHomePage constants
 *
 */

export const DEFAULT_ACTION = 'app/PricingHomePage/DEFAULT_ACTION';
