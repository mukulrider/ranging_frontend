// import { fromJS } from 'immutable';
// import { makeSelectPricingHomePageDomain } from '../selectors';

// const selector = makeSelectPricingHomePageDomain();

describe('makeSelectPricingHomePageDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
