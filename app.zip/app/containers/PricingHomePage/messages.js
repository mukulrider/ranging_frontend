/*
 * PricingHomePage Messages
 *
 * This contains all the text for the PricingHomePage component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.containers.PricingHomePage.header',
    defaultMessage: 'This is PricingHomePage container !',
  },
});
