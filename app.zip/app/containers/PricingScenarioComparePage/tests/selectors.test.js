// import { fromJS } from 'immutable';
// import { makeSelectPricingScenarioComparePageDomain } from '../selectors';

// const selector = makeSelectPricingScenarioComparePageDomain();

describe('makeSelectPricingScenarioComparePageDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
