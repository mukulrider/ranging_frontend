/*
 *
 * PricingScenarioComparePage constants
 *
 */

export const DEFAULT_ACTION = 'app/PricingScenarioComparePage/DEFAULT_ACTION';
export const FETCH_SCENARIO_DATA = 'app/PricingScenarioComparePage/FETCH_SCENARIO_DATA';
export const FETCH_SCENARIO_DATA_SUCCESS = 'app/PricingScenarioComparePage/FETCH_SCENARIO_DATA_SUCCESS';
