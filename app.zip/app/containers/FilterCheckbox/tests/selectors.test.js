// import { fromJS } from 'immutable';
// import { makeSelectFilterCheckboxDomain } from '../selectors';

// const selector = makeSelectFilterCheckboxDomain();

describe('makeSelectFilterCheckboxDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
