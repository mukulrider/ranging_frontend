/*
 * FilterCheckbox Messages
 *
 * This contains all the text for the FilterCheckbox component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.containers.FilterCheckbox.header',
    defaultMessage: 'This is FilterCheckbox container !',
  },
});
