/*
 *
 * FilterCheckbox constants
 *
 */

export const DEFAULT_ACTION = 'app/FilterCheckbox/DEFAULT_ACTION';
