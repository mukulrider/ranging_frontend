/*
 *
 * RangingHomePage constants
 *
 */

export const DEFAULT_ACTION = 'app/RangingHomePage/DEFAULT_ACTION';
export const API_FETCH = 'app/RangingHomePage/API_FETCH';
export const API_FETCH_SUCCESS = 'app/RangingHomePage/API_FETCH_SUCCESS';
