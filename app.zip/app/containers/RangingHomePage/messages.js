/*
 * RangingHomePage Messages
 *
 * This contains all the text for the RangingHomePage component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.containers.RangingHomePage.header',
    defaultMessage: 'This is RangingHomePage container !',
  },
});
