// import React from 'react';
// import { shallow } from 'enzyme';

// import { RangingHomePage } from '../index';

describe('<RangingHomePage />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
