// import { fromJS } from 'immutable';
// import { makeSelectRangingHomePageDomain } from '../selectors';

// const selector = makeSelectRangingHomePageDomain();

describe('makeSelectRangingHomePageDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
