// import { fromJS } from 'immutable';
// import { makeSelectPricingScenarioTrackerPageDomain } from '../selectors';

// const selector = makeSelectPricingScenarioTrackerPageDomain();

describe('makeSelectPricingScenarioTrackerPageDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
