/*
 *
 * PricingScenarioTrackerPage constants
 *
 */

export const DEFAULT_ACTION = 'app/PricingScenarioTrackerPage/DEFAULT_ACTION';
export const SCENARIO_STATUS = 'app/PricingScenarioTrackerPage/SCENARIO_STATUS';
export const SCENARIO_STATUS_SUCCESS = 'app/PricingScenarioTrackerPage/SCENARIO_STATUS_SUCCESS';
