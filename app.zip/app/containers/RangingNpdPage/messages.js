/*
 * RangingNpdPage Messages
 *
 * This contains all the text for the RangingNpdPage component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.containers.RangingNpdPage.header',
    defaultMessage: 'This is RangingNpdPage container !',
  },
});
