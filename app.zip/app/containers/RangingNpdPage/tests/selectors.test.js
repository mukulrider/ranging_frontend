// import { fromJS } from 'immutable';
// import { makeSelectRangingNpdPageDomain } from '../selectors';

// const selector = makeSelectRangingNpdPageDomain();

describe('makeSelectRangingNpdPageDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
