// import React from 'react';
// import { shallow } from 'enzyme';

// import { RangingNpdPage } from '../index';

describe('<RangingNpdPage />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
