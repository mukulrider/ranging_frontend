// import { fromJS } from 'immutable';
// import { makeSelectUserInputPageDomain } from '../selectors';

// const selector = makeSelectUserInputPageDomain();

describe('makeSelectUserInputPageDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
