/*
 *
 * UserInputPage constants
 *
 */

export const DEFAULT_ACTION = 'app/UserInputPage/DEFAULT_ACTION';
