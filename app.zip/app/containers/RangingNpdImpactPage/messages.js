/*
 * RangingNpdImpactPage Messages
 *
 * This contains all the text for the RangingNpdImpactPage component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.containers.RangingNpdImpactPage.header',
    defaultMessage: 'This is RangingNpdImpactPage container !',
  },
});
