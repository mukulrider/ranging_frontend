// import React from 'react';
// import { shallow } from 'enzyme';

// import { RangingNpdImpactPage } from '../index';

describe('<RangingNpdImpactPage />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
