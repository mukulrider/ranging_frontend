// import { fromJS } from 'immutable';
// import { makeSelectRangingNpdImpactPageDomain } from '../selectors';

// const selector = makeSelectRangingNpdImpactPageDomain();

describe('makeSelectRangingNpdImpactPageDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
