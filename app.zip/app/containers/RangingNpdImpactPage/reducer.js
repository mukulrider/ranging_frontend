/*
 *
 * RangingNpdImpactPage reducer
 *
 */

import {fromJS} from 'immutable';
import {
  DEFAULT_ACTION, BUBBLE_CHART_TABLE_SUCCESS, BUBBLE_CHART_DATA_SUCCESS, CANNIBALIZED_PROD_TABLE_DATA_SUCCESS,WATERFALL_CHART_DATA_SUCCESS,
  GENERATE_SIDE_FILTER_SUCCESS, GENERATE_URL_PARAMS, GENERATE_URL_PARAMS_STRING,
  SEND_URL_PARAMS, SAVE_WEEK_PARAM, SAVE_PAGE_PARAM
} from './constants';

const initialState = fromJS({
  dataPageUrlParams: '',
  dataWeekUrlParams: '',
  urlParamsString: '',
  // waterFallChartData: {
  //   "impact": {"perc_impact_psg": '--', "Cannibilization_perc": '--'}
  //   // "data": [{"name": "NPD_Volume", "value": 140}, {"name": "Cannibilization_perc", "value": -40}]
  // }
  // npd_bubble_table_data: [
  //   {
  //     "base_product_number": 73940233,
  //     "long_description": "TAITTINGER      COMTES DE       CHAMPAGNE 75CL",
  //     "pps": "-44.11",
  //     "cps": "0.00",
  //     "store_count": 65,
  //     "rate_of_sale": "-10.85"
  //   },
  //   {
  //     "base_product_number": 77688427,
  //     "long_description": "CHATEAU MOUTON  ROTHSCHILD      2010 75CL",
  //     "pps": "-7549.08",
  //     "cps": "0.00",
  //     "store_count": 1,
  //     "rate_of_sale": "42000.00"
  //   }
  // ],
  // npd_bubble_chart_data:[
  //   {
  //     "rate_of_sale": 4200,
  //     "pps_quartile": 0.25,
  //     "performance_quartile": "Low CPS/Low Profit",
  //     "long_description": "CHATEAU MOUTON  ROTHSCHILD      2010 75CL",
  //     "cps_quartile": 0.2
  //   },
  //   {
  //     "rate_of_sale": 3632.84,
  //     "pps_quartile": 0.85,
  //     "performance_quartile": "Low CPS/Low Profit",
  //     "long_description": "KRUG            GRAND CUVEE     75CL",
  //     "cps_quartile": 0.1
  //   },
  //   {
  //     "rate_of_sale": 3372.64,
  //     "pps_quartile": 0.43,
  //     "performance_quartile": "Low CPS/Low Profit",
  //     "long_description": "BOLLINGER GRANDEANNEE VINTAGE   CHAMPAGNE 75CL",
  //     "cps_quartile": 0.5
  //   }
  //   ],
  // canniProdTableData:{
  //   "df": [
  //     {
  //       "brand_name": "HARDYS          ",
  //       "sales_volume": "568386.00",
  //       "brand_indicator": "Brand",
  //       "long_description": "HARDY'S STAMP   ROSE 75CL",
  //       "sales_value": "2902566.17"
  //     },{
  //       "brand_name": "BAROSSA         ",
  //       "sales_volume": "14.00",
  //       "brand_indicator": "Brand",
  //       "long_description": "BAROSSA DRIVE   SHIRAZ",
  //       "sales_value": "71.54"
  //     }]
  // }
});

function rangingNpdImpactPageReducer(state = initialState, action) {
  switch (action.type) {
    case DEFAULT_ACTION:
      return state;
    case BUBBLE_CHART_TABLE_SUCCESS :
      // console.log(BUBBLE_CHART_TABLE_SUCCESS , 'reducer', action);
      return state.set('npd_bubble_table_data', action.data);
    case BUBBLE_CHART_DATA_SUCCESS :
      // console.log(BUBBLE_CHART_DATA_SUCCESS , 'reducer', action);
      return state.set('npd_bubble_chart_data', action.data);
    case CANNIBALIZED_PROD_TABLE_DATA_SUCCESS :
      console.log(CANNIBALIZED_PROD_TABLE_DATA_SUCCESS, 'reducer', action);
      return state.set('canniProdTableData', action.data);
    case WATERFALL_CHART_DATA_SUCCESS :
      console.log(WATERFALL_CHART_DATA_SUCCESS, 'reducer', action);
      return state.set('waterFallChartData', action.data);
    case SEND_URL_PARAMS:
      // console.log("Updated the state in Reducer", action.data);
      return state.set('dataUrlParms', action.data);
    case SAVE_WEEK_PARAM:
      // console.log("Updated the week state in Reducer", action.data);
      return state.set('dataWeekUrlParams', action.data);
    case SAVE_PAGE_PARAM:
      // console.log("Updated the PAGE state in Reducer", action.data);
      return state.set('dataPageUrlParams', action.data);
    case GENERATE_SIDE_FILTER_SUCCESS :
      // console.log(action);
      return state.set('sideFilter', action.data);
    case GENERATE_URL_PARAMS:
      return state.set('urlParams', action.data);
    case GENERATE_URL_PARAMS_STRING:
      return state.set('urlParamsString', action.data);
    default:
      return state;
  }
}

export default rangingNpdImpactPageReducer;
