/*
 *
 * RangingNpdImpactPage actions
 *
 */

import {
  DEFAULT_ACTION,
  DATA_FETCH_ON_PAGE_LOAD,BUBBLE_CHART_TABLE_SUCCESS,
  BUBBLE_CHART_DATA_SUCCESS,BUBBLE_CHART_DATA_FETCH,
  GENERATE_SIDE_FILTER,GENERATE_SIDE_FILTER_SUCCESS,
  GENERATE_URL_PARAMS,GENERATE_URL_PARAMS_STRING,
  SEND_URL_PARAMS,SAVE_WEEK_PARAM,SAVE_PAGE_PARAM,
  WATERFALL_CHART_DATA_FETCH,WATERFALL_CHART_DATA_SUCCESS,
  CANNIBALIZED_PROD_TABLE_DATA_FETCH,CANNIBALIZED_PROD_TABLE_DATA_SUCCESS,

} from './constants';

//--------------------- DEFAULT ACTIONS -------------------------------

export function defaultAction() {
  return {
    type: DEFAULT_ACTION,
  };
}

//--------------------- DATA FETCH ON PAGE LOAD -------------------------------

export function dataFetchOnPageLoad() {
  // console.log('dataFetchOnPageLoad action');
  return {
    type: DATA_FETCH_ON_PAGE_LOAD,
  };
}

export function dataFetchOnBubbleTableSuccess(data) {
  // console.log('dataFetchOnPageLoadSuccess action', data);
  return {
    type: BUBBLE_CHART_TABLE_SUCCESS ,
    data
  };
}

//--------------------- DATA FOR BUBBLE CHART -------------------------------

export function dataFetchOnBubbleData() {
  // console.log('dataFetchOnBubbleData action');
  return {
    type: BUBBLE_CHART_DATA_FETCH,
  };
}

export function dataFetchOnBubbleDataSuccess(data) {
  // console.log('dataFetchOnBubbleDataSuccess action', data);
  return {
    type: BUBBLE_CHART_DATA_SUCCESS ,
    data
  };
}

//--------------------- DATA FOR WATERFALL CHART & IMPACT NUMBERS -------------------------------

export function dataFetchOnWaterFallChart() {
  // console.log('dataFetchOnWaterFallChart action');
  return {
    type: WATERFALL_CHART_DATA_FETCH,
  };
}

export function dataFetchOnWaterFallChartSuccess(data) {
  // console.log('dataFetchOnBubbleDataSuccess action', data);
  return {
    type: WATERFALL_CHART_DATA_SUCCESS ,
    data
  };
}

//--------------------- DATA FOR CANNIBALIZATION TABLE -------------------------------

export function dataFetchCanniProdTable() {
  console.log('dataFetchCanniProdTable action');
  return {
    type: CANNIBALIZED_PROD_TABLE_DATA_FETCH,
  };
}

export function dataFetchCanniProdTableSuccess(data) {
  console.log('dataFetchCanniProdTableSuccess action', data);
  return {
    type: CANNIBALIZED_PROD_TABLE_DATA_SUCCESS,
    data
  };
}

//--------------------- DATA FOR FILTERS -------------------------------

export function generateSideFilter() {
  return {
    type: GENERATE_SIDE_FILTER
  }
}

export function generateSideFilterSuccess(data) {
  return {
    type: GENERATE_SIDE_FILTER_SUCCESS,
    data
  }
}

//--------------------- SAVING IN PARAMS IN REDUCER -------------------------------

export function generateUrlParams(data) {

  return {
    type: GENERATE_URL_PARAMS,
    data
  }
}

export function generateUrlParamsString(data) {

  return {
    type: GENERATE_URL_PARAMS_STRING,
    data
  }
}

export function sendUrlParams(data) {
  // console.log('Saving url params in action',data);
  return {
    type: SEND_URL_PARAMS ,
    data
  };
}

export function saveWeekParam(data) {
  // console.log('Saving url params in action',data);
  return {
    type: SAVE_WEEK_PARAM ,
    data
  };
}

export function savePageParam(data) {
  // console.log('Saving url params in action',data);
  return {
    type: SAVE_PAGE_PARAM ,
    data
  };
}

