/*
 *
 * RangingNpdImpactPage
 *
 */

import React, {PropTypes} from 'react';
import {connect} from 'react-redux';
import Helmet from 'react-helmet';
import {FormattedMessage} from 'react-intl';
import {createStructuredSelector} from 'reselect';
import makeSelectRangingNpdImpactPage from './selectors';
import messages from './messages';
// -----------------------------------------
import {browserHistory} from 'react-router';
import Button from 'components/button';
import './style.scss';
import Panel from 'components/panel';
import Spinner from 'components/spinner';
import BubbleChartNpd from 'components/BubbleChartNpd';
import WaterFallChartNpd from 'components/WaterFallChartNpd';
import SelectorNpdImpact from 'components/SelectorNpdImpact';
import {
  dataFetchOnPageLoad,dataFetchOnBubbleData,dataFetchCanniProdTable,dataFetchOnWaterFallChart,
  sendUrlParams,generateSideFilter, generateUrlParams, generateUrlParamsString,
  saveWeekParam,savePageParam,
} from './actions';


export class RangingNpdImpactPage extends React.PureComponent { // eslint-disable-line react/prefer-stateless-function



  componentDidMount = () => {
    this.props.onSendUrlParams(this.props.location.query);

    this.props.onDataFetchOnBubbleData();
    this.props.onDataFetchCanniProdTable();
    this.props.onDataFetchOnWaterFallChart();
    this.props.onDataFetchOnPageLoad();
    this.props.onGenerateSideFilter();

  };

  componentDidUpdate = () => {
    this.props.onSendUrlParams(this.props.location.query);


  };


  render() {


    //For url parameters
    let dataWeekUrlParams=this.props.RangingNpdImpactPage.dataWeekUrlParams;
    let dataPageUrlParams=this.props.RangingNpdImpactPage.dataPageUrlParams;
    // let dataPageTwoUrlParams=this.props.RangingNpdImpactPage.dataPageTwoUrlParams;
    let dataFilterUrlParams=this.props.RangingNpdImpactPage.urlParamsString;
    // console.log('dataWeekUrlParams',dataWeekUrlParams);
    // console.log('dataPageUrlParams',dataPageUrlParams);
    // console.log('dataFilterUrlParams',dataFilterUrlParams);


    let formatSales = (i) => {
      if(i>=1000 || i<=-1000) {
        let rounded=Math.round(i /1000);
        return ('£ ' + rounded.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") + 'K');
    }

    else{
      return ('£ ' + Math.round(i));
    }
    };


    let formatVolume = (i) => {
      if(i>=1000 || i<=-1000)
      { let rounded=Math.round(i /1000)
        return (rounded.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") + 'K');

      }else{
        return (Math.round(i));
      }


    };


    return (
      <div>

        <Helmet
          title="RangingNpdImpactPage"
          meta={[
            {name: 'description', content: 'Description of RangingNpdImpactPage'},
          ]}
        />

        {/*Week Tabs*/}
        <div className="row">
          <Button onClick={() => {
            dataWeekUrlParams="time_period=Last 13 Weeks";
            this.props.onSaveWeekParam(dataWeekUrlParams);
            if (dataFilterUrlParams!==''&& dataPageUrlParams!=='') {
              browserHistory.push(this.props.location.pathname+"?"+dataWeekUrlParams+"&"+dataFilterUrlParams+"&"+dataPageUrlParams);
            } else if (dataFilterUrlParams!==''|| dataPageUrlParams!=='') {
              browserHistory.push(this.props.location.pathname+"?"+dataWeekUrlParams+"&"+dataFilterUrlParams+dataPageUrlParams);
            }
            else{
              browserHistory.push(this.props.location.pathname+"?"+dataWeekUrlParams);
            }

          }}>13 Weeks</Button>

          <Button onClick={() => {
            dataWeekUrlParams="time_period=Last 26 Weeks";
            this.props.onSaveWeekParam(dataWeekUrlParams);
            if (dataFilterUrlParams!==''&& dataPageUrlParams!=='') {
              browserHistory.push(this.props.location.pathname+"?"+dataWeekUrlParams+"&"+dataFilterUrlParams+"&"+dataPageUrlParams);
            } else if (dataFilterUrlParams!==''|| dataPageUrlParams!=='') {
              browserHistory.push(this.props.location.pathname+"?"+dataWeekUrlParams+"&"+dataFilterUrlParams+dataPageUrlParams);
            }
            else{
              browserHistory.push(this.props.location.pathname+"?"+dataWeekUrlParams);
            }

          }}>26 Weeks</Button>

          <Button onClick={() => {
            dataWeekUrlParams="time_period=Last 52 Weeks";
            this.props.onSaveWeekParam(dataWeekUrlParams);
            if (dataFilterUrlParams!==''&& dataPageUrlParams!=='') {
              browserHistory.push(this.props.location.pathname+"?"+dataWeekUrlParams+"&"+dataFilterUrlParams+"&"+dataPageUrlParams);
            } else if (dataFilterUrlParams!==''|| dataPageUrlParams!=='') {
              browserHistory.push(this.props.location.pathname+"?"+dataWeekUrlParams+"&"+dataFilterUrlParams+dataPageUrlParams);
            }
            else{
              browserHistory.push(this.props.location.pathname+"?"+dataWeekUrlParams);
            }
          }}>52 Weeks</Button>
        </div>

        {/*Content*/}
        <div className="row">

          {/*Filters*/}
          <div className="col-xs-2">
          <Panel>
            <SelectorNpdImpact sideFilter={this.props.RangingNpdImpactPage.sideFilter}
            location={this.props.location}

            onGenerateUrlParams={this.props.onGenerateUrlParams}
            onGenerateUrlParamsString={this.props.onGenerateUrlParamsString}
            onSendUrlParams={this.props.onSendUrlParams}

            onDataFetchOnBubbleData={this.props.onDataFetchOnBubbleData}
            onDataFetchCanniProdTable={this.props.onDataFetchCanniProdTable}
            onDataFetchOnWaterFallChart={this.props.onDataFetchOnWaterFallChart}
            onDataFetchOnPageLoad={this.props.onDataFetchOnPageLoad}

            dataWeekUrlParams={dataWeekUrlParams}
            dataPageUrlParams={dataPageUrlParams}
            dataFilterUrlParams={dataPageUrlParams}


          />
          </Panel>
            {/*onGenerateTable={this.props.onGenerateTable}*/}
          </div>


          {/*Content*/}
          <div className="col-xs-10">

            <Panel>

              {/*Net Impact (Waterfall chart and table)*/}
              <Panel>
              <div className="row">
                <div className="col-xs-12">
                  <div className="net-impact-row">

                    <div>
                      <h4 className="row-header"> NET IMPACT </h4>
                    </div>

                    {/*Value*/}
                    <div className="col-xs-6">
                        <Panel>
                          <div className="dashed-border center-this">
                            <h4> VALUE </h4>
                          </div>
                          {/*<h5>Water fall chart</h5>*/}

                           {/*Waterfall chart*/}
                          {(() => {
                            if (this.props.RangingNpdImpactPage.waterFallChartData) {
                              return (
                                <WaterFallChartNpd data={{chart_data:this.props.RangingNpdImpactPage.waterFallChartData.data,chart_id:"net_impact_waterfall"}}/>
                              )
                            }})()}

                          {/*Impact numbers*/}
                          <div className="row">
                            <div className="col-xs-12">

                              <div className="col-xs-6 center-this">
                                <Panel>
                                  <div className="dashed-border">
                                    <h4> % CANNIBALIZATION</h4>
                                  </div>

                                  {(() => {
                                    if (this.props.RangingNpdImpactPage.waterFallChartData) {
                                      console.log('this.props.RangingNpdImpactPage.waterFallChartData',this.props.RangingNpdImpactPage.waterFallChartData);
                                      return (
                                        <div className="cannibalization-perc-number">
                                          {this.props.RangingNpdImpactPage.waterFallChartData.impact.Cannibilized_volume} %
                                        </div>
                                      )
                                    }})()}

                                </Panel>
                              </div>

                              <div className="col-xs-6 center-this">
                                <Panel>
                                  <div className="dashed-border">
                                    <h4> % IMPACT IN PSG </h4>
                                  </div>

                                  {(() => {
                                    if (this.props.RangingNpdImpactPage.waterFallChartData) {
                                      return (
                                        <div className="cannibalization-perc-number">
                                          {this.props.RangingNpdImpactPage.waterFallChartData.impact.perc_impact_psg} %
                                        </div>
                                      )
                                    }})()}
                                </Panel>
                              </div>
                            </div>



                          </div>

                        </Panel>
                      </div>

                    {/*Volume*/}
                    <div className="col-xs-6">
                      <Panel>
                        <div className="dashed-border center-this">
                          <h4> VOLUME </h4>
                        </div>

                     {/*Waterfall chart*/}
                        {(() => {
                          if (this.props.RangingNpdImpactPage.waterFallChartData) {
                            return (
                              <WaterFallChartNpd data={{chart_data:this.props.RangingNpdImpactPage.waterFallChartData.data,chart_id:"net_impact_waterfall_2"}}/>
                            )
                          }})()}

                        {/*Impact numbers*/}
                        <div className="row">
                          <div className="col-xs-12">

                            <div className="col-xs-6 center-this">
                              <Panel>
                                <div className="dashed-border">
                                  <h4> % CANNIBALIZATION</h4>
                                </div>

                                {(() => {
                                  if (this.props.RangingNpdImpactPage.waterFallChartData) {
                                    console.log('this.props.RangingNpdImpactPage.waterFallChartData',this.props.RangingNpdImpactPage.waterFallChartData);
                                    return (
                                      <div className="cannibalization-perc-number">
                                        {this.props.RangingNpdImpactPage.waterFallChartData.impact.Cannibilized_volume} %
                                      </div>
                                    )
                                  }})()}

                              </Panel>
                            </div>

                            <div className="col-xs-6 center-this">
                              <Panel>
                                <div className="dashed-border">
                                  <h4> % IMPACT IN PSG </h4>
                                </div>

                                {(() => {
                                  if (this.props.RangingNpdImpactPage.waterFallChartData) {
                                    return (
                                      <div className="cannibalization-perc-number">
                                        {this.props.RangingNpdImpactPage.waterFallChartData.impact.perc_impact_psg} %
                                      </div>
                                    )
                                  }})()}
                              </Panel>
                            </div>
                          </div>



                        </div>

                      </Panel>
                    </div>
                  </div>
                </div>
              </div>
              </Panel>

              {/*Cannibalization Table*/}
              <Panel>
                <div className="row">
                  <div className="col-xs-12">
                    <div className="net-cannibalized-prod">
                       <h4 className="row-header">CURRENT PRODUCTS THAT MIGHT BE CANNIBALIZED</h4>

                        {/*Table*/}
                        <div id="table">
                        <table className="table table-hover table-striped table-bordered " width="100%">
                          <thead>
                            <th>Branded Name</th>
                            <th>Brand Indicator</th>
                            <th>Products Description</th>
                            <th>Volume</th>
                            <th>Sales Value</th>

                          </thead>
                          <tbody>
                            {(() => {
                            if (this.props.RangingNpdImpactPage.canniProdTableData) {
                              return this.props.RangingNpdImpactPage.canniProdTableData.df.map(obj => {

                                return (
                                  <tr key={Math.random() + Date.now()}>
                                    <td>{obj.brand_name}</td>
                                    <td>{obj.brand_indicator}</td>
                                    <td>{obj.long_description}</td>
                                    <td>{formatVolume(obj.sales_volume)}</td>
                                    <td>{formatSales(obj.sales_value)}</td>
                                  </tr>
                                )
                              })
                            }else{
                              <Spinner/>
                            }
                          })()}
                          </tbody>
                        </table>

                          <div>

                            {[1, 2, 3, 4, 5, 6].map(obj => {
                              return (

                                <button onClick={() => {
                                  let rowsPerTable = 8;
                                  let page = obj;
                                  let starting_row=(((page-1)*(rowsPerTable))+1);
                                  dataPageUrlParams="t1_startRow="+starting_row;
                                  this.props.onSavePageParam(dataPageUrlParams);

                                  if (dataFilterUrlParams!==''&& dataWeekUrlParams!=='') {
                                    browserHistory.push(this.props.location.pathname+"?"+dataWeekUrlParams+"&"+dataFilterUrlParams+"&"+dataPageUrlParams);
                                  } else if (dataFilterUrlParams!==''|| dataWeekUrlParams!=='') {
                                    browserHistory.push(this.props.location.pathname+"?"+dataWeekUrlParams+dataFilterUrlParams+"&"+dataPageUrlParams);
                                  }
                                  else{
                                    browserHistory.push(this.props.location.pathname+"?"+dataPageUrlParams);
                                  }

                                }}>{obj}</button>

                              )
                            })}

                          </div>

                      </div>

                    </div>
                  </div>
                </div>
              </Panel>

              {/*Supplier Impact(Table and bubble chart*/}
              <Panel>
                <div className="row">
                  <div className="col-xs-12">
                    <div className="supplier-performance">
                      <h4 className="row-header">SUPPLIER PERFORMANCE IN PAST</h4>

                      {/*Bubble Chart*/}
                      <div className="col-xs-6 ">
                        {(() => {
                          if (this.props.RangingNpdImpactPage.npd_bubble_chart_data) {
                            console.log("Entered the bubble function in index");
                            return (
                              <BubbleChartNpd
                                data={[this.props.RangingNpdImpactPage.npd_bubble_chart_data, "bubble_chart_npd", "cps_quartile", "pps_quartile", "rate_of_sale"]}/>
                            )
                          }})()}

                      </div>

                      {/*Table*/}
                      <div className="col-xs-6">
                        <div id="table">
                          <table className="table table-hover table-striped table-bordered " width="100%">
                            <thead>
                            <tr key={Math.random() + Date.now()}>
                              <th>BPN</th>
                              <th>Description</th>
                              <th>CPS</th>
                              <th>Profit / Store</th>
                            </tr>
                            </thead>
                            <tbody>
                            {(() => {
                              if (this.props.RangingNpdImpactPage.npd_bubble_table_data) {
                              return this.props.RangingNpdImpactPage.npd_bubble_table_data.map(obj => {

                              return (
                              <tr key={Math.random() + Date.now()}>
                                <td>{obj.base_product_number}</td>
                                <td>{obj.long_description}</td>
                                <td>{obj.cps}</td>
                                <td>{obj.pps}</td>
                              </tr>
                            )
                            })
                            }
                            })()}
                            </tbody>
                          </table>

                          <div>

                            {[1, 2, 3, 4, 5, 6].map(obj => {
                              return (

                                <button onClick={() => {
                                  let rowsPerTable = 8;
                                  let page = obj;
                                  let starting_row=(((page-1)*(rowsPerTable))+1);
                                  dataPageUrlParams="t2_startRow="+starting_row;
                                  this.props.onSavePageParam(dataPageUrlParams);

                                  if (dataFilterUrlParams!==''&& dataWeekUrlParams!=='') {
                                    browserHistory.push(this.props.location.pathname+"?"+dataWeekUrlParams+"&"+dataFilterUrlParams+"&"+dataPageUrlParams);
                                  } else if (dataFilterUrlParams!==''|| dataWeekUrlParams!=='') {
                                    browserHistory.push(this.props.location.pathname+"?"+dataWeekUrlParams+dataFilterUrlParams+"&"+dataPageUrlParams);
                                  }
                                  else{
                                    browserHistory.push(this.props.location.pathname+"?"+dataPageUrlParams);
                                  }

                                }}>{obj}</button>

                              )
                            })}

                          </div>

                        </div>
                      </div>

                    </div>
                  </div>
                </div>
              </Panel>

            </Panel>

          </div>

        </div>


      </div>
    );
  }
}

RangingNpdImpactPage.propTypes = {

};

const mapStateToProps = createStructuredSelector({
  RangingNpdImpactPage: makeSelectRangingNpdImpactPage(),
});

function mapDispatchToProps(dispatch) {
  return {
    onDataFetchOnPageLoad: (e) => dispatch(dataFetchOnPageLoad(e)),
    onDataFetchOnBubbleData: (e) => dispatch(dataFetchOnBubbleData(e)),
    onDataFetchCanniProdTable: (e) => dispatch(dataFetchCanniProdTable(e)),
    onDataFetchOnWaterFallChart: (e) => dispatch(dataFetchOnWaterFallChart(e)),


    //----Filter----
    onGenerateSideFilter: (e) => dispatch(generateSideFilter(e)),
    onGenerateTable: (e) => dispatch(generateTable(e)),
    onSendUrlParams: (e) => dispatch(sendUrlParams(e)),
    onGenerateUrlParams: (e) => dispatch(generateUrlParams(e)),
    onGenerateUrlParamsString: (e) => dispatch(generateUrlParamsString(e)),


    onSaveWeekParam: (e) => dispatch(saveWeekParam(e)),
    onSavePageParam: (e) => dispatch(savePageParam(e)),

  };
}

export default connect(mapStateToProps, mapDispatchToProps)(RangingNpdImpactPage);
