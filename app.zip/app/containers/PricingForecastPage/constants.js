/*
 *
 * PricingForecastPage constants
 *
 */

export const DEFAULT_ACTION = 'app/PricingForecastPage/DEFAULT_ACTION';
export const FETCH_GRAPH_DATA = 'app/PricingForecastPage/FETCH_GRAPH_DATA';
export const SELECTED_TYPE = 'app/PricingForecastPage/SELECTED_TYPE';
export const FETCH_GRAPH_DATA_SUCCESS = 'app/PricingForecastPage/FETCH_GRAPH_DATA_SUCCESS';
