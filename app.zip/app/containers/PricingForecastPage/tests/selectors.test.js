// import { fromJS } from 'immutable';
// import { makeSelectPricingForecastPageDomain } from '../selectors';

// const selector = makeSelectPricingForecastPageDomain();

describe('makeSelectPricingForecastPageDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
