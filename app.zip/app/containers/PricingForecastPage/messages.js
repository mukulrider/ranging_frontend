/*
 * PricingForecastPage Messages
 *
 * This contains all the text for the PricingForecastPage component.
 */
import { defineMessages } from 'react-intl';

export default defineMessages({
  header: {
    id: 'app.containers.PricingForecastPage.header',
    defaultMessage: 'This is PricingForecastPage container !',
  },
});
