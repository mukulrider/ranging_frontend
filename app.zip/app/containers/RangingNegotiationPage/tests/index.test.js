// import React from 'react';
// import { shallow } from 'enzyme';

// import { RangingNegotiationPage } from '../index';

describe('<RangingNegotiationPage />', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
