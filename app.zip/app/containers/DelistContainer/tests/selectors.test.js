// import { fromJS } from 'immutable';
// import { makeSelectDelistContainerDomain } from '../selectors';

// const selector = makeSelectDelistContainerDomain();

describe('makeSelectDelistContainerDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
