// import { fromJS } from 'immutable';
// import { makeSelectPricingScenarioOverviewPageDomain } from '../selectors';

// const selector = makeSelectPricingScenarioOverviewPageDomain();

describe('makeSelectPricingScenarioOverviewPageDomain', () => {
  it('Expect to have unit tests specified', () => {
    expect(true).toEqual(false);
  });
});
