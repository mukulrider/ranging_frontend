/*
 *
 * PricingScenarioOverviewPage constants
 *
 */

export const DEFAULT_ACTION = 'app/PricingScenarioOverviewPage/DEFAULT_ACTION';
export const OVERVIEW_FETCH = 'app/PricingScenarioOverviewPage/OVERVIEW_FETCH';
export const OVERVIEW_FETCH_SUCCESS = 'app/PricingScenarioOverviewPage/OVERVIEW_FETCH_SUCCESS';
export const CHECKBOX_CHANGE = 'app/PricingScenarioOverviewPage/CHECKBOX_CHANGE';
export const URL_PARAMS_DATA = 'app/PricingScenarioOverviewPage/URL_PARAMS_DATA';
export const GENERATE_URL_PARAMS_STRING = 'app/PricingScenarioOverviewPage/GENERATE_URL_PARAMS_STRING';
export const GENERATE_URL_PARAMS_DATA = 'app/PricingScenarioOverviewPage/GENERATE_URL_PARAMS_DATA';
export const GENERATE_URL_PARAMS_DATA_SUCCESS = 'app/PricingScenarioOverviewPage/GENERATE_URL_PARAMS_DATA_SUCCESS';
